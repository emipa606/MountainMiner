﻿using RimWorld;
using Verse;

namespace MountainMiner
{
    [DefOf]
    public static class JobDefOf_MM
    {
        public static JobDef OperateHighDrill;
    }
}
